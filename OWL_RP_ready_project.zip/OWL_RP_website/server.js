import express from "express";
import { createClient } from "@supabase/supabase-js";

const app = express();
app.use(express.json({ limit: "200kb" }));
app.use(express.static("public"));

const required = ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY", "SUPABASE_ANON_KEY"];
const missing = required.filter(k => !process.env[k]);
const db = missing.length ? null : createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false }
});
const authClient = missing.length ? null : createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, {
  auth: { persistSession: false, autoRefreshToken: false }
});

const roles = ["user", "moderator", "admin", "coowner", "owner"];
const rank = Object.fromEntries(roles.map((r, i) => [r, i]));

async function auth(req, res, next) {
  if (!db) return res.status(503).json({ error: "Сайт ещё не настроен: добавьте переменные Supabase." });
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ error: "Войдите в аккаунт." });
  const { data, error } = await authClient.auth.getUser(token);
  if (error || !data?.user) return res.status(401).json({ error: "Сессия истекла. Войдите снова." });
  req.user = data.user;
  const { data: profile } = await db.from("profiles").select("*").eq("id", req.user.id).maybeSingle();
  const isOwnerEmail = process.env.OWNER_EMAIL && req.user.email?.toLowerCase() === process.env.OWNER_EMAIL.toLowerCase();
  if (!profile) {
    const { data: created, error: createError } = await db.from("profiles").insert({
      id: req.user.id, email: req.user.email, username: req.user.user_metadata?.username || req.user.email?.split("@")[0] || "Игрок",
      role: isOwnerEmail ? "owner" : "user"
    }).select().single();
    if (createError) return res.status(500).json({ error: "Не удалось создать профиль." });
    req.profile = created;
  } else {
    req.profile = profile;
    if (isOwnerEmail && profile.role !== "owner") {
      const { data: updated } = await db.from("profiles").update({ role: "owner" }).eq("id", req.user.id).select().single();
      if (updated) req.profile = updated;
    }
  }
  next();
}

function minRole(role) {
  return (req, res, next) => {
    if ((rank[req.profile?.role] ?? -1) < rank[role]) return res.status(403).json({ error: "Недостаточно прав." });
    next();
  };
}
async function telegram(text) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return { sent: false, reason: "Telegram пока не подключён" };
  const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", disable_web_page_preview: true })
  });
  const result = await response.json();
  return { sent: Boolean(result.ok), reason: result.ok ? null : "Telegram не принял сообщение" };
}

app.get("/api/health", (_req, res) => res.json({ ok: true, configured: Boolean(db) }));
app.get("/api/news", async (_req, res) => {
  if (!db) return res.json([]);
  const { data, error } = await db.from("news").select("*").order("created_at", { ascending: false }).limit(30);
  if (error) return res.status(500).json({ error: "Не удалось загрузить новости." });
  res.json(data || []);
});
app.get("/api/team", async (_req, res) => {
  if (!db) return res.json([]);
  const { data } = await db.from("profiles").select("username, role").in("role", ["owner", "coowner", "admin", "moderator"]).order("role");
  res.json(data || []);
});
app.get("/api/me", auth, async (req, res) => {
  const { data: applications } = await db.from("applications").select("id, status, created_at, answer").eq("user_id", req.user.id).order("created_at", { ascending: false }).limit(10);
  res.json({ profile: req.profile, applications: applications || [] });
});
app.post("/api/applications", auth, async (req, res) => {
  const { character, age, about, experience, reason } = req.body || {};
  if (![character, age, about, experience, reason].every(v => typeof v === "string" && v.trim()) || character.length > 60 || about.length > 1500 || experience.length > 1200 || reason.length > 1200) {
    return res.status(400).json({ error: "Заполните все поля. Слишком длинный текст сокращён." });
  }
  const { data, error } = await db.from("applications").insert({
    user_id: req.user.id, username: req.profile.username, character: character.trim(),
    age: age.trim(), about: about.trim(), experience: experience.trim(), reason: reason.trim(), status: "На рассмотрении"
  }).select().single();
  if (error) return res.status(500).json({ error: "Не удалось сохранить заявку. Попробуйте позже." });
  const tg = await telegram(
    `🦉 <b>Новая заявка OWL RP</b>\nИгрок: ${escapeHtml(req.profile.username)}\nПерсонаж: ${escapeHtml(character)}\nВозраст: ${escapeHtml(age)}\nО себе: ${escapeHtml(about)}\nОпыт RP: ${escapeHtml(experience)}\nПочему хочет вступить: ${escapeHtml(reason)}\nID заявки: ${data.id}`
  );
  res.json({ ok: true, application: data, telegramSent: tg.sent, message: tg.sent ? "Заявка отправлена!" : "Заявка сохранена. Уведомление Telegram пока не настроено." });
});
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c])); }

app.get("/api/admin/applications", auth, minRole("moderator"), async (_req, res) => {
  const { data, error } = await db.from("applications").select("*").order("created_at", { ascending: false }).limit(100);
  if (error) return res.status(500).json({ error: "Ошибка загрузки заявок." });
  res.json(data || []);
});
app.patch("/api/admin/applications/:id", auth, minRole("moderator"), async (req, res) => {
  const { status, answer = "" } = req.body || {};
  if (!["На рассмотрении", "Одобрена", "Отклонена"].includes(status)) return res.status(400).json({ error: "Недопустимый статус." });
  const { data, error } = await db.from("applications").update({ status, answer: String(answer).slice(0, 500) }).eq("id", req.params.id).select().single();
  if (error) return res.status(500).json({ error: "Не удалось обновить заявку." });
  res.json(data);
});
app.post("/api/admin/news", auth, minRole("admin"), async (req, res) => {
  const { title, body } = req.body || {};
  if (!title?.trim() || !body?.trim()) return res.status(400).json({ error: "Заполните заголовок и текст." });
  const { data, error } = await db.from("news").insert({ title: title.trim().slice(0, 100), body: body.trim().slice(0, 3000), author: req.profile.username }).select().single();
  if (error) return res.status(500).json({ error: "Не удалось опубликовать новость." });
  res.json(data);
});
app.delete("/api/admin/news/:id", auth, minRole("admin"), async (req, res) => {
  const { error } = await db.from("news").delete().eq("id", req.params.id);
  if (error) return res.status(500).json({ error: "Не удалось удалить новость." });
  res.json({ ok: true });
});
app.get("/api/admin/staff", auth, minRole("admin"), async (_req, res) => {
  const { data, error } = await db.from("profiles").select("id, username, email, role").neq("role", "user").order("role");
  if (error) return res.status(500).json({ error: "Ошибка загрузки команды." });
  res.json(data || []);
});
app.patch("/api/admin/staff/:id", auth, minRole("owner"), async (req, res) => {
  const { role } = req.body || {};
  if (!["user", "moderator", "admin", "coowner"].includes(role)) return res.status(400).json({ error: "Эту роль нельзя назначить." });
  if (req.params.id === req.user.id) return res.status(400).json({ error: "Нельзя менять собственную роль." });
  const { data, error } = await db.from("profiles").update({ role }).eq("id", req.params.id).select("id, username, email, role").single();
  if (error) return res.status(500).json({ error: "Не удалось изменить роль." });
  res.json(data);
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`OWL RP запущен на порту ${port}`));
