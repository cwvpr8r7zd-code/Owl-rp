import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

// Вставьте публичные данные проекта Supabase в эти две строки после создания проекта.
const SUPABASE_URL = "";
const SUPABASE_ANON_KEY = "";
const supabase = SUPABASE_URL && SUPABASE_ANON_KEY ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
let session = null, me = null;
const $ = id => document.getElementById(id);
const msg = (id, text) => { $(id).textContent = text || ""; };
async function api(path, options={}) {
  if (!session) throw new Error("Сначала войдите в аккаунт.");
  const response = await fetch(path, { ...options, headers: { "Content-Type":"application/json", Authorization:`Bearer ${session.access_token}`, ...(options.headers||{}) } });
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || "Ошибка запроса.");
  return data;
}
function setHidden(id, hidden) { $(id).classList.toggle("hidden", hidden); }
async function refreshMe() {
  if (!session) { me=null; setHidden("applyForm",true); setHidden("cabinet",true); setHidden("admin",true); setHidden("authBox",false); $("accountBtn").textContent="Войти"; return; }
  me = await api("/api/me");
  setHidden("authBox",true); setHidden("applyForm",false); setHidden("cabinet",false);
  $("accountBtn").textContent=me.profile.username;
  $("profileText").textContent=`${me.profile.username} • ${roleName(me.profile.role)}`;
  $("myApplications").innerHTML = me.applications.length ? me.applications.map(a=>`<div class="status">Заявка #${a.id} — <b>${esc(a.status)}</b><br><small>${new Date(a.created_at).toLocaleString("ru-RU")}</small>${a.answer?`<br>${esc(a.answer)}`:""}</div>`).join("") : "<p class='muted'>Пока заявок нет. Заполни анкету выше!</p>";
  setHidden("admin", !["moderator","admin","coowner","owner"].includes(me.profile.role));
}
function roleName(r){return ({user:"Игрок",moderator:"Модератор",admin:"Администратор",coowner:"Совладелец",owner:"Владелец"})[r]||r}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function boot() {
  if (!supabase) { msg("authMsg","Сайт подготовлен. Для входа владелец должен подключить Supabase (инструкция в README)."); }
  else {
    const {data}=await supabase.auth.getSession(); session=data.session;
    supabase.auth.onAuthStateChange((_event,s)=>{session=s; refreshMe().catch(e=>msg("authMsg",e.message));});
    if(session) await refreshMe().catch(()=>{});
  }
  await loadNews(); await loadTeam();
}
$("login").onclick=async()=>{try{if(!supabase)throw Error("Сначала настройте Supabase по README.");const {data,error}=await supabase.auth.signInWithPassword({email:$("email").value,password:$("password").value});if(error)throw error;session=data.session;await refreshMe();msg("authMsg","Вы вошли!");}catch(e){msg("authMsg",e.message)}};
$("signup").onclick=async()=>{try{if(!supabase)throw Error("Сначала настройте Supabase по README.");const {data,error}=await supabase.auth.signUp({email:$("email").value,password:$("password").value,options:{data:{username:$("email").value.split("@")[0]}}});if(error)throw error;session=data.session;if(session)await refreshMe();msg("authMsg",data.session?"Аккаунт создан!":"Проверьте почту и подтвердите регистрацию.");}catch(e){msg("authMsg",e.message)}};
$("logout").onclick=async()=>{await supabase.auth.signOut();session=null;await refreshMe()};
$("accountBtn").onclick=()=>location.href="#apply";
$("applyForm").onsubmit=async e=>{e.preventDefault();try{const form=Object.fromEntries(new FormData(e.currentTarget));const result=await api("/api/applications",{method:"POST",body:JSON.stringify(form)});msg("applyMsg",result.message);await refreshMe();}catch(err){msg("applyMsg",err.message)}};
async function loadNews(){try{const items=await (await fetch("/api/news")).json();$("newsList").innerHTML=items.length?items.map(n=>`<article><b>${new Date(n.created_at).toLocaleDateString("ru-RU")}</b><h3>${esc(n.title)}</h3><p>${esc(n.body)}</p><small>${esc(n.author||"Команда OWL RP")}</small></article>`).join(""):"<p class='muted'>Пока новостей нет. Скоро здесь появятся объявления!</p>";}catch{$("newsList").textContent="Новости временно недоступны."}}
async function loadTeam(){try{const items=await(await fetch("/api/team")).json();$("teamList").innerHTML=items.length?items.map(p=>`<article><b>${roleName(p.role)}</b><h3>${esc(p.username)}</h3><p>Команда OWL RP</p></article>`).join(""):"<p class='muted'>Состав команды появится после регистрации владельца.</p>";}catch{}}
document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
async function showTab(tab){const box=$("adminContent");try{
 if(tab==="applications"){const list=await api("/api/admin/applications");box.innerHTML=list.map(a=>`<div class="adminitem"><b>#${a.id} · ${esc(a.username)} · ${esc(a.character)}</b><p>Возраст: ${esc(a.age)}<br>О себе: ${esc(a.about)}<br>Опыт: ${esc(a.experience)}<br>Причина: ${esc(a.reason)}</p><select id="s${a.id}"><option ${a.status==="На рассмотрении"?"selected":""}>На рассмотрении</option><option ${a.status==="Одобрена"?"selected":""}>Одобрена</option><option ${a.status==="Отклонена"?"selected":""}>Отклонена</option></select> <input id="a${a.id}" placeholder="Комментарий игроку" value="${esc(a.answer)}"><button class="soft" onclick="window.saveApp(${a.id})">Сохранить</button></div>`).join("")||"Заявок пока нет.";}
 if(tab==="newsAdmin"){box.innerHTML=`<h3>Опубликовать новость</h3><input id="newsTitle" placeholder="Заголовок"><textarea id="newsBody" placeholder="Текст новости"></textarea><button class="primary" id="publish">Опубликовать</button><p id="newsMsg" class="msg"></p>`;$("publish").onclick=async()=>{try{await api("/api/admin/news",{method:"POST",body:JSON.stringify({title:$("newsTitle").value,body:$("newsBody").value})});msg("newsMsg","Новость опубликована!");await loadNews()}catch(e){msg("newsMsg",e.message)}};}
 if(tab==="staff"){const list=await api("/api/admin/staff");box.innerHTML=list.map(p=>`<div class="adminitem"><b>${esc(p.username)}</b> <small>${esc(p.email)}</small><p>${roleName(p.role)}</p>${me.profile.role==="owner"?`<select id="r${p.id}"><option value="moderator">Модератор</option><option value="admin">Администратор</option><option value="coowner">Совладелец</option><option value="user">Снять роль</option></select> <button class="soft" onclick="window.saveRole('${p.id}')">Изменить</button>`:""}</div>`).join("")||"Пока никого нет.";}
 }catch(e){box.textContent=e.message}}
window.saveApp=async id=>{try{await api(`/api/admin/applications/${id}`,{method:"PATCH",body:JSON.stringify({status:$("s"+id).value,answer:$("a"+id).value})});alert("Статус обновлён.");}catch(e){alert(e.message)}};
window.saveRole=async id=>{try{await api(`/api/admin/staff/${id}`,{method:"PATCH",body:JSON.stringify({role:$("r"+id).value})});alert("Роль обновлена.");showTab("staff");}catch(e){alert(e.message)}};
boot().catch(console.error);
